# NearbyBazaar Backend

Instructions to run the backend.